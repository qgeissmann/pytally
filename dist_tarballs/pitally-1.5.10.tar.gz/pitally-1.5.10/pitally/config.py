import logging
STATIC_VIDEO_DIR = "/videos/"
FTP_DRIVE_PATH = "/srv/ftp/"
FTP_HOSTNAME = "pitally-drive.lan"
FTP = "ftp://" + FTP_HOSTNAME
FTP_USER = "pi"
FTP_PASSWORD = "pitally_01234"
MOCK_DEVICE_MAP = False
LOGGING_LEVEL = logging.DEBUG

NETWORK_SSID = "pitally"
NETWORK_PSK = "pitally_01234"
NETWORK_COUNTRY = "CA"

PI_PASSWORD="pitally_01234"
